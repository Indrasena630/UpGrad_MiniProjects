# IT Incident Auto-Triage & Tracker — Mini Project 3

A Python CLI tool that automatically classifies IT incidents and pushes them to ServiceNow, Jira, and Azure Boards via REST APIs, then generates a styled HTML summary report.

---

## Project Structure

```
incident_tracker/
├── main.py                   CLI entry point; orchestrates the full pipeline
├── config.py                 API credentials and MOCK_API flag
├── models/
│   ├── __init__.py
│   ├── incident.py           Incident base class + NetworkIncident, AppIncident, SecurityIncident
│   └── report.py             ReportGenerator — HTML & JSON output
├── services/
│   ├── __init__.py
│   ├── servicenow.py         ServiceNow REST API integration
│   ├── jira.py               Jira REST API integration
│   └── azure_boards.py       Azure Boards REST API integration
├── utils/
│   ├── __init__.py
│   ├── classifier.py         Regex-based type and severity detection
│   ├── decorators.py         @log_call and @retry decorators
│   └── helpers.py            map / filter / reduce helper functions
├── data/
│   └── incidents.json        12 sample incident records
└── output/                   Auto-created on run
    ├── report.html           Styled HTML report
    ├── report.json           JSON summary
    └── app.log               Execution log
```

---

## Setup

### Prerequisites
- Python 3.10 or later
- No external libraries required for mock mode

### Install dependencies (for live mode only)
```bash
pip install requests
```

### Configuration
Open `config.py` and set:

| Setting | Default | Description |
|---------|---------|-------------|
| `MOCK_API` | `True` | Set to `False` for live API calls |
| `SNOW_INSTANCE` | `your-instance` | ServiceNow instance name |
| `SNOW_USERNAME` | `admin` | ServiceNow username |
| `SNOW_PASSWORD` | `your_password` | ServiceNow password |
| `JIRA_DOMAIN` | `your-domain` | Atlassian domain |
| `JIRA_EMAIL` | `you@acme.com` | Jira account email |
| `JIRA_API_TOKEN` | `your_jira_api_token` | Jira API token |
| `JIRA_PROJECT` | `PROJ` | Jira project key |
| `AZURE_ORG` | `your-org` | Azure DevOps organisation |
| `AZURE_PROJECT` | `your-project` | Azure DevOps project |
| `AZURE_PAT` | `your_pat` | Azure Personal Access Token |

---

## Running the Project

### Mock mode (default — no live credentials needed)
```bash
cd incident_tracker
python main.py
```

### Filter by severity (stretch goal)
```bash
python main.py --severity critical
python main.py --severity high
```

### Custom input file
```bash
python main.py --input data/incidents.json
```

---

## Expected Output

```
══════════════════════════════════════════════════════════════════════
  🛡️  IT INCIDENT AUTO-TRIAGE & TRACKER
  Mode: MOCK (no live API calls)
══════════════════════════════════════════════════════════════════════

ID       TYPE       SEV        TEAM         TITLE
────────────────────────────────────────────────────────────────────────
INC001   network    critical   DBA          Database connection timeout on prod-db01
INC004   network    critical   Network      Network switch offline in DC rack B
...

── Severity breakdown: {'critical': 3, 'high': 3, 'medium': 4, 'low': 2}
── Type breakdown   : {'network': 4, 'security': 4, 'app': 4}
── Team breakdown   : {'DBA': 1, 'Security': 4, 'Backend': 4, 'Network': 3}

── Pushing incidents to platforms (batch size = 3) ──────────────────
  [ServiceNow MOCK] Ticket ID : MOCK-SNOW-INC001
  [Jira MOCK]       Issue key : PROJ-MOCK-INC001
  [Azure MOCK]      Work Item : AZ-MOCK-INC001
  ...

✅ HTML report written → output/report.html
✅ JSON export written → output/report.json
```

---

## Python Concepts Demonstrated

| Concept | Where used |
|---------|-----------|
| OOP — Inheritance | `Incident` → `NetworkIncident`, `AppIncident`, `SecurityIncident` |
| Abstract method (`NotImplementedError`) | `Incident.classify()` |
| Properties (`@property`) | `Incident.severity`, `Incident.incident_type` |
| Dunder methods | `__str__`, `__repr__`, `__lt__`, `__iter__`, `__next__` |
| Static methods | `Incident.validate_schema()` |
| Decorators | `@log_call`, `@retry(times=3)` |
| Generators | `batch_incidents()`, generator expression in `main.py` |
| `map` / `filter` / `reduce` | `utils/helpers.py` |
| Regex (`re.compile`, `IGNORECASE`) | `utils/classifier.py`, all subclasses |
| File I/O | `ReportGenerator.generate_html()`, `export_json()` |
| JSON parsing | `main.py → load_incidents()` |
| CLI args (`argparse`) | `main.py` |
| Exception handling | `@retry`, `load_incidents()` |
| Custom iterator protocol | `IncidentIterator` |
| `datetime` / ISO 8601 | `Incident.__init__()` |
| `functools.reduce` | `count_by_team()`, `count_by_severity()`, `count_by_type()` |

---

## Stretch Goals Implemented

- ✅ `--severity` CLI flag to filter which incidents get pushed
- ✅ Generator expression in `main.py` (with comment explaining why)
- ✅ `Incident.validate_schema()` static method validates JSON before loading
- ✅ Live API integration ready — just set `MOCK_API = False` in `config.py`

---

## Submission

Zip the project as:
```
[YourBatchNo]_[YourName]_Incident_Tracker_MiniProject_3.zip
```

Include:
- All source files
- `README.md`
- `output/report.html` (from a mock-mode run)