#!/usr/bin/env python3
# main.py
"""
IT Incident Auto-Triage & Tracker
==================================
CLI entry point — orchestrates the full pipeline:
  1. Load incidents from JSON
  2. Classify each incident (type + severity)
  3. Push to ServiceNow, Jira, Azure Boards (mock or live)
  4. Generate HTML + JSON report

Usage
-----
  python main.py                         # process all incidents
  python main.py --severity critical     # only critical incidents
  python main.py --severity high
"""

import argparse
import json
import logging
import os
import sys

import config
from models.incident import (
    Incident,
    NetworkIncident,
    AppIncident,
    SecurityIncident,
    IncidentIterator,
    batch_incidents,
)
from models.report import ReportGenerator
from services.azure_boards import AzureBoardsClient
from services.jira import JiraClient
from services.servicenow import ServiceNowClient
from utils.classifier import detect_type, detect_severity
from utils.helpers import (
    count_by_severity,
    count_by_team,
    count_by_type,
    get_critical_incidents,
)

# ── Logging setup ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level   = getattr(logging, config.LOG_LEVEL, logging.INFO),
    format  = config.LOG_FORMAT,
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("output/app.log", mode="w", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)


# ── Factory: build the right subclass from a raw JSON record ──────────────────
def _build_incident(record: dict) -> Incident:
    """
    Use detect_type() to decide which subclass to instantiate.
    validate_schema() is called first (static method stretch goal).
    """
    if not Incident.validate_schema(record):
        raise ValueError(f"Invalid record schema: {record.get('id', '?')}")

    text          = f"{record['title']} {record['description']}"
    incident_type = detect_type(text)

    common = dict(
        id           = record["id"],
        title        = record["title"],
        description  = record["description"],
        reported_by  = record["reported_by"],
        timestamp    = record["timestamp"],
        assigned_team= record["assigned_team"],
    )

    if incident_type == "network":
        return NetworkIncident(**common)
    elif incident_type == "security":
        return SecurityIncident(**common)
    elif incident_type == "app":
        return AppIncident(**common)
    else:
        return Incident(**common)   # general — won't have a custom classify()


# ── Load incidents from JSON ──────────────────────────────────────────────────
def load_incidents(path: str) -> list:
    logger.info("Loading incidents from %s", path)
    with open(path, encoding="utf-8") as fh:
        records = json.load(fh)
    incidents = []
    for rec in records:
        try:
            inc = _build_incident(rec)
            inc.classify()
            incidents.append(inc)
            logger.debug("Loaded: %s", inc)
        except (ValueError, NotImplementedError) as exc:
            logger.error("Skipping record %s: %s", rec.get("id", "?"), exc)
    logger.info("Loaded and classified %d incidents.", len(incidents))
    return incidents


# ── Push one incident to all three platforms ──────────────────────────────────
def push_to_platforms(incident: Incident, snow: ServiceNowClient,
                       jira: JiraClient, azure: AzureBoardsClient) -> None:
    print(f"\n  ── {incident.id} [{incident.severity.upper()}] {incident.title[:60]}")
    incident.ticket_ids["snow"]  = snow.create_ticket(incident)
    incident.ticket_ids["jira"]  = jira.create_issue(incident)
    incident.ticket_ids["azure"] = azure.create_work_item(incident)

    # Type-specific side-effects
    if isinstance(incident, NetworkIncident) and incident.severity in ("critical", "high"):
        incident.escalate()
    elif isinstance(incident, SecurityIncident):
        incident.notify_soc()
    elif isinstance(incident, AppIncident) and incident.severity in ("critical", "high"):
        incident.get_stack_trace()


# ── Main pipeline ─────────────────────────────────────────────────────────────
def main() -> None:
    # ── CLI args ──────────────────────────────────────────────────────────────
    parser = argparse.ArgumentParser(description="IT Incident Auto-Triage & Tracker")
    parser.add_argument(
        "--severity",
        choices=["critical", "high", "medium", "low"],
        default=None,
        help="Only process incidents of this severity (stretch goal).",
    )
    parser.add_argument(
        "--input",
        default=os.path.join("data", "incidents.json"),
        help="Path to the input JSON file.",
    )
    args = parser.parse_args()

    os.makedirs("output", exist_ok=True)

    print("\n" + "═" * 70)
    print("  🛡️  IT INCIDENT AUTO-TRIAGE & TRACKER")
    print(f"  Mode: {'MOCK (no live API calls)' if config.MOCK_API else 'LIVE'}")
    if args.severity:
        print(f"  Filter: --severity {args.severity}")
    print("═" * 70 + "\n")

    # ── 1. Load & classify ────────────────────────────────────────────────────
    all_incidents = load_incidents(args.input)

    # ── 2. Optional severity filter (stretch goal --severity flag) ────────────
    if args.severity:
        incidents = list(filter(lambda i: i.severity == args.severity, all_incidents))
        print(f"Filtered to {len(incidents)} '{args.severity}' incidents.\n")
    else:
        incidents = all_incidents

    # ── 3. Print classification summary ──────────────────────────────────────
    print(f"{'ID':<8} {'TYPE':<10} {'SEV':<10} {'TEAM':<12} TITLE")
    print("─" * 72)
    for inc in sorted(incidents):
        print(
            f"{inc.id:<8} {(inc.incident_type or 'general'):<10} "
            f"{(inc.severity or '?'):<10} {inc.assigned_team:<12} {inc.title[:40]}"
        )

    # Helper stats
    sev_counts  = count_by_severity(incidents)
    type_counts = count_by_type(incidents)
    team_counts = count_by_team(incidents)

    print("\n── Severity breakdown:", sev_counts)
    print("── Type breakdown   :", type_counts)
    print("── Team breakdown   :", team_counts)

    critical_list = get_critical_incidents(incidents)
    if critical_list:
        print(f"\n⚠️  {len(critical_list)} CRITICAL incident(s) detected!")

    # ── 4. Initialise platform clients ───────────────────────────────────────
    snow  = ServiceNowClient()
    jira  = JiraClient()
    azure = AzureBoardsClient()

    # ── 5. Push in batches of 3 ───────────────────────────────────────────────
    print("\n── Pushing incidents to platforms (batch size = 3) ──────────────────")
    # Using a generator expression for batch iteration (stretch goal)
    processed = (
        inc
        for batch in batch_incidents(incidents, batch_size=3)
        for inc in batch
    )

    for inc in processed:
        push_to_platforms(inc, snow, jira, azure)

    # ── 6. Iterate with IncidentIterator (demonstrate custom iterator) ─────────
    print("\n── Critical incidents via IncidentIterator ──────────────────────────")
    for inc in IncidentIterator(incidents, severity_filter="critical"):
        print(f"  ✔ {inc.id} | {inc.incident_type} | {inc.title[:55]}")

    # ── 7. Generate reports ───────────────────────────────────────────────────
    reporter = ReportGenerator(all_incidents)   # full dataset in the report
    reporter.generate_html("output/report.html")
    reporter.export_json("output/report.json")

    print("\n" + "═" * 70)
    print("  ✅ Pipeline complete!")
    print("  📄 output/report.html   — open in a browser")
    print("  📋 output/report.json   — machine-readable summary")
    print("  📝 output/app.log       — full execution log")
    print("═" * 70 + "\n")


if __name__ == "__main__":
    main()