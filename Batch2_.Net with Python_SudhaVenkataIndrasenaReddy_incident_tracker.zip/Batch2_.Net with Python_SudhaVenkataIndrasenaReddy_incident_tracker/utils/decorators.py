# utils/decorators.py
"""
Reusable decorators.

@log_call   — logs entry and exit of any function
@retry      — retries a function up to N times on exception
"""

import functools
import logging
import time

logger = logging.getLogger(__name__)


def log_call(func):
    """Log function name on entry and exit."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger.info("→ Calling  : %s", func.__name__)
        result = func(*args, **kwargs)
        logger.info("✓ Completed: %s", func.__name__)
        return result
    return wrapper


def retry(times: int = 3, delay: float = 1.0, exceptions: tuple = (Exception,)):
    """
    Retry decorator.

    Parameters
    ----------
    times      : int   — maximum number of attempts
    delay      : float — seconds to wait between retries
    exceptions : tuple — which exception types to catch and retry

    If the function still raises after all attempts, the last exception
    propagates to the caller.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, times + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    last_exc = exc
                    logger.warning(
                        "Attempt %d/%d for %s failed: %s",
                        attempt, times, func.__name__, exc,
                    )
                    if attempt < times:
                        time.sleep(delay)
            # All attempts exhausted
            logger.error("All %d attempts failed for %s.", times, func.__name__)
            raise last_exc
        return wrapper
    return decorator