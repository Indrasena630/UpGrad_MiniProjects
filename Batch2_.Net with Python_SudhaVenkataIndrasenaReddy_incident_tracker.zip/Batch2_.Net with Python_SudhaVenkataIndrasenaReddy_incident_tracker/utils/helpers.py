# utils/helpers.py
"""
Functional helpers using map, filter, and reduce.
"""

from functools import reduce
from typing import Dict, List

from models.incident import Incident


def get_critical_incidents(incidents: List[Incident]) -> List[Incident]:
    """Return only critical-severity incidents (filter)."""
    return list(filter(lambda i: i.severity == "critical", incidents))


def get_incidents_by_severity(incidents: List[Incident], severity: str) -> List[Incident]:
    """Return incidents matching any given severity level (filter)."""
    return list(filter(lambda i: i.severity == severity, incidents))


def build_jira_payloads(incidents: List[Incident]) -> List[dict]:
    """Serialize every incident to a dict ready for the Jira payload (map)."""
    return list(map(lambda i: i.to_dict(), incidents))


def count_by_team(incidents: List[Incident]) -> Dict[str, int]:
    """Count incidents per assigned team (reduce)."""
    return reduce(
        lambda acc, i: {**acc, i.assigned_team: acc.get(i.assigned_team, 0) + 1},
        incidents,
        {},
    )


def count_by_severity(incidents: List[Incident]) -> Dict[str, int]:
    """Count incidents per severity level (reduce)."""
    return reduce(
        lambda acc, i: {**acc, (i.severity or "unknown"): acc.get(i.severity or "unknown", 0) + 1},
        incidents,
        {},
    )


def count_by_type(incidents: List[Incident]) -> Dict[str, int]:
    """Count incidents per incident type (reduce)."""
    return reduce(
        lambda acc, i: {**acc, (i.incident_type or "general"): acc.get(i.incident_type or "general", 0) + 1},
        incidents,
        {},
    )


def get_titles(incidents: List[Incident]) -> List[str]:
    """Extract just the titles of all incidents (map)."""
    return list(map(lambda i: i.title, incidents))