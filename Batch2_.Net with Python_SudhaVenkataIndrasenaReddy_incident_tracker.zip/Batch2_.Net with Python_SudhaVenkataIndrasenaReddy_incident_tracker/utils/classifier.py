# utils/classifier.py
"""
Regex-based type and severity detection.

Public API
----------
detect_type(text: str)     -> 'network' | 'security' | 'app' | 'general'
detect_severity(text: str) -> 'critical' | 'high' | 'medium' | 'low'

All patterns compiled with re.IGNORECASE so raw-data casing is irrelevant.
"""

import re

# ── Type patterns ─────────────────────────────────────────────────────────────
NETWORK_RE = re.compile(
    r"\b("
    r"\d{1,3}(?:\.\d{1,3}){3}(?:/\d{1,2})?"   # IPv4 / CIDR
    r"|TCP|UDP|ICMP|VLAN|MPLS|BGP|OSPF"
    r"|switch|firewall|router|gateway"
    r"|packet\s+loss|dns|bandwidth|port\s+\d+"
    r")\b",
    re.IGNORECASE,
)

SECURITY_RE = re.compile(
    r"\b("
    r"breach|ransomware|brute[-\s]?force|malware|phishing"
    r"|unauthorized|exploit|ddos|sql[-\s]?injection|xss"
    r"|intrusion|vulnerability|credential|zero[-\s]?day"
    r")\b",
    re.IGNORECASE,
)

APP_RE = re.compile(
    r"\b("
    r"\w+Exception|\w+Error"              # Java/Python exception names
    r"|error[-_\s]?code|stack\s+trace"
    r"|HTTP[-\s]?\d{3}"                  # HTTP status codes
    r"|[A-Z][A-Z0-9_\-]{2,}-\d{3,}"     # Structured error codes like NPE-4021
    r"|NullPointerException|timeout|500|503|404"
    r")\b",
    re.IGNORECASE,
)

# ── Severity patterns ─────────────────────────────────────────────────────────
CRITICAL_KW = re.compile(
    r"\b(outage|down|offline|breach|ransomware|production|crash|critical|disaster)\b",
    re.IGNORECASE,
)

HIGH_KW = re.compile(
    r"\b(timeout|failing|unavailable|unreachable|exception|error|attack|brute[-\s]?force|malware)\b",
    re.IGNORECASE,
)

MEDIUM_KW = re.compile(
    r"\b(slow|degraded|warning|intermittent|phishing|packet\s+loss|latency)\b",
    re.IGNORECASE,
)


# ── Public functions ──────────────────────────────────────────────────────────
def detect_type(text: str) -> str:
    """
    Return the best-fit incident type for the given text.
    Priority: security > network > app > general
    """
    # Count matches to pick the dominant type
    security_hits = len(SECURITY_RE.findall(text))
    network_hits  = len(NETWORK_RE.findall(text))
    app_hits      = len(APP_RE.findall(text))

    scores = {
        "security": security_hits,
        "network":  network_hits,
        "app":      app_hits,
    }

    best = max(scores, key=lambda k: scores[k])
    if scores[best] == 0:
        return "general"
    return best


def detect_severity(text: str) -> str:
    """
    Return the severity level for the given text.
    Priority: critical > high > medium > low
    """
    if CRITICAL_KW.search(text):
        return "critical"
    if HIGH_KW.search(text):
        return "high"
    if MEDIUM_KW.search(text):
        return "medium"
    return "low"