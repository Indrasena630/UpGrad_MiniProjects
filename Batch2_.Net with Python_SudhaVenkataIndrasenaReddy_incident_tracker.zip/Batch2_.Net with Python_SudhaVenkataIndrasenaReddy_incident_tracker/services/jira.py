# services/jira.py
"""
Jira REST API v3 integration.
POST /rest/api/3/issue  — create issue
PUT  /rest/api/3/issue/{key} — update priority / status

All methods decorated with @log_call and @retry(times=3).
"""

import base64
import logging

import config
from utils.decorators import log_call, retry

logger = logging.getLogger(__name__)

# ── Severity → Jira priority mapping ─────────────────────────────────────────
_PRIORITY = {"critical": "Highest", "high": "High", "medium": "Medium", "low": "Low"}


def _make_auth_header() -> str:
    """Base64-encode email:api_token for Bearer auth."""
    raw   = f"{config.JIRA_EMAIL}:{config.JIRA_API_TOKEN}"
    token = base64.b64encode(raw.encode()).decode()
    return f"Basic {token}"


class JiraClient:
    """Thin wrapper around the Jira Cloud REST API."""

    def __init__(self) -> None:
        self.base_url = config.JIRA_BASE_URL
        self.project  = config.JIRA_PROJECT
        self.mock     = config.MOCK_API
        self._headers = {
            "Authorization":  _make_auth_header(),
            "Content-Type":   "application/json",
            "Accept":         "application/json",
        }

    @log_call
    @retry(times=3, delay=1)
    def create_issue(self, incident) -> str:
        """
        Create a Jira Bug issue.
        Returns the issue key, e.g. PROJ-42.
        """
        payload = {
            "fields": {
                "project":     {"key": self.project},
                "summary":     incident.title,
                "description": {
                    "type":    "doc",
                    "version": 1,
                    "content": [
                        {
                            "type":    "paragraph",
                            "content": [{"type": "text", "text": incident.description}],
                        }
                    ],
                },
                "issuetype": {"name": "Bug"},
                "priority":  {"name": _PRIORITY.get(incident.severity, "Medium")},
                "labels":    [incident.incident_type or "general", incident.assigned_team],
            }
        }

        if self.mock:
            mock_key = f"{self.project}-MOCK-{incident.id}"
            logger.info("[MOCK] Jira payload for %s: %s", incident.id, payload)
            print(f"  [Jira MOCK] Would POST to {self.base_url}")
            print(f"  [Jira MOCK] Payload    : summary={incident.title!r}")
            print(f"  [Jira MOCK] Issue key  : {mock_key}\n")
            return mock_key

        import requests

        resp = requests.post(self.base_url, json=payload, headers=self._headers, timeout=15)
        resp.raise_for_status()
        key = resp.json()["key"]
        logger.info("Jira issue created: %s for incident %s", key, incident.id)
        return key

    @log_call
    @retry(times=3, delay=1)
    def update_issue(self, key: str, priority: str = "Medium") -> bool:
        """PUT an update to an existing Jira issue."""
        if self.mock:
            print(f"  [Jira MOCK] PUT {key} → priority={priority}")
            return True

        import requests

        url  = f"{self.base_url}/{key}"
        resp = requests.put(
            url,
            json={"fields": {"priority": {"name": priority}}},
            headers=self._headers,
            timeout=15,
        )
        resp.raise_for_status()
        return True