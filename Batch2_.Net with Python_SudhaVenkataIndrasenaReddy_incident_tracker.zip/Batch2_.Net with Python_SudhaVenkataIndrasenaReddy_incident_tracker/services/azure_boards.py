# services/azure_boards.py
"""
Azure Boards REST API integration.
POST /_apis/wit/workitems/$Bug?api-version=7.1  — create work item

Uses JSON Patch format with Personal Access Token (PAT) auth.
All methods decorated with @log_call and @retry(times=3).
"""

import base64
import logging

import config
from utils.decorators import log_call, retry

logger = logging.getLogger(__name__)

# ── Severity → Azure priority ─────────────────────────────────────────────────
_PRIORITY = {"critical": 1, "high": 2, "medium": 3, "low": 4}


def _make_pat_header() -> str:
    """Base64-encode ':PAT' for Basic auth (Azure DevOps standard)."""
    raw   = f":{config.AZURE_PAT}"
    token = base64.b64encode(raw.encode()).decode()
    return f"Basic {token}"


class AzureBoardsClient:
    """Thin wrapper around the Azure DevOps Work Items REST API."""

    def __init__(self) -> None:
        self.base_url = config.AZURE_BASE_URL
        self.mock     = config.MOCK_API
        self._headers = {
            "Authorization": _make_pat_header(),
            "Content-Type":  "application/json-patch+json",
        }

    @log_call
    @retry(times=3, delay=1)
    def create_work_item(self, incident) -> str:
        """
        Create a Bug work item in Azure Boards.
        Returns the work-item ID as a string.
        """
        patch_doc = [
            {
                "op":    "add",
                "path":  "/fields/System.Title",
                "value": incident.title,
            },
            {
                "op":    "add",
                "path":  "/fields/System.Description",
                "value": incident.description,
            },
            {
                "op":    "add",
                "path":  "/fields/Microsoft.VSTS.Common.Priority",
                "value": _PRIORITY.get(incident.severity, 3),
            },
            {
                "op":    "add",
                "path":  "/fields/System.AssignedTo",
                "value": incident.assigned_team,
            },
            {
                "op":    "add",
                "path":  "/fields/System.Tags",
                "value": f"{incident.incident_type}; {incident.severity}",
            },
        ]

        if self.mock:
            mock_id = f"AZ-MOCK-{incident.id}"
            logger.info("[MOCK] Azure Boards patch for %s: %s", incident.id, patch_doc)
            print(f"  [Azure Boards MOCK] Would POST to {self.base_url}")
            print(f"  [Azure Boards MOCK] Title      : {incident.title!r}")
            print(f"  [Azure Boards MOCK] Work Item  : {mock_id}\n")
            return mock_id

        import requests

        resp = requests.post(
            self.base_url,
            json=patch_doc,
            headers=self._headers,
            timeout=15,
        )
        resp.raise_for_status()
        work_item_id = str(resp.json()["id"])
        logger.info("Azure work item created: %s for incident %s", work_item_id, incident.id)
        return work_item_id