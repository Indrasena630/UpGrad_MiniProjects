# services/servicenow.py
"""
ServiceNow REST API integration.
POST  /api/now/table/incident  — create ticket
PATCH /api/now/table/incident/{sys_id} — update status

All methods are decorated with @log_call and @retry(times=3).
Set MOCK_API = True in config.py to run without live credentials.
"""

import logging
import uuid

import config
from utils.decorators import log_call, retry

logger = logging.getLogger(__name__)

# ── Severity → ServiceNow urgency mapping ─────────────────────────────────────
_URGENCY = {"critical": 1, "high": 1, "medium": 2, "low": 3}

# ── Category mapping ──────────────────────────────────────────────────────────
_CATEGORY = {"network": "Network", "app": "Software", "security": "Security", "general": "Inquiry"}


class ServiceNowClient:
    """Thin wrapper around the ServiceNow Incident REST API."""

    def __init__(self) -> None:
        self.base_url = config.SNOW_BASE_URL
        self.auth     = (config.SNOW_USERNAME, config.SNOW_PASSWORD)
        self.mock     = config.MOCK_API

    @log_call
    @retry(times=3, delay=1)
    def create_ticket(self, incident) -> str:
        """
        Create a ServiceNow incident ticket.
        Returns the sys_id of the created record.
        """
        payload = {
            "short_description": incident.title,
            "description":       incident.description,
            "urgency":           str(_URGENCY.get(incident.severity, 3)),
            "category":          _CATEGORY.get(incident.incident_type, "Inquiry"),
            "assignment_group":  incident.assigned_team,
            "caller_id":         incident.reported_by,
        }

        if self.mock:
            mock_id = f"MOCK-SNOW-{incident.id}"
            logger.info("[MOCK] ServiceNow payload for %s: %s", incident.id, payload)
            print(f"  [ServiceNow MOCK] Would POST to {self.base_url}")
            print(f"  [ServiceNow MOCK] Payload   : {payload}")
            print(f"  [ServiceNow MOCK] Ticket ID : {mock_id}\n")
            return mock_id

        # ── Live call ──────────────────────────────────────────────────────
        import requests  # imported lazily so mock mode has no dependency

        resp = requests.post(
            self.base_url,
            json=payload,
            auth=self.auth,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
        sys_id = resp.json()["result"]["sys_id"]
        logger.info("ServiceNow ticket created: %s for incident %s", sys_id, incident.id)
        return sys_id

    @log_call
    @retry(times=3, delay=1)
    def update_status(self, sys_id: str, state: str = "2") -> bool:
        """
        PATCH an existing ServiceNow incident to update its state.
        state codes: 1=New, 2=In Progress, 6=Resolved, 7=Closed
        """
        if self.mock:
            print(f"  [ServiceNow MOCK] PATCH {sys_id} → state={state}")
            return True

        import requests

        url  = f"{self.base_url}/{sys_id}"
        resp = requests.patch(
            url,
            json={"state": state},
            auth=self.auth,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
        return True