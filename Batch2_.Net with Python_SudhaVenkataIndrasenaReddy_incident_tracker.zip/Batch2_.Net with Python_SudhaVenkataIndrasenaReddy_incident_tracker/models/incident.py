


from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Iterator, List, Optional

logger = logging.getLogger(__name__)

# ── Severity ordering (lower int = higher urgency) ────────────────────────────
_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


# ═══════════════════════════════════════════════════════════════════════════════
# Base class
# ═══════════════════════════════════════════════════════════════════════════════
class Incident:
    """Abstract base class for all incident types."""

    def __init__(
        self,
        id: str,
        title: str,
        description: str,
        reported_by: str,
        timestamp: str,
        assigned_team: str,
    ) -> None:
        self.id            = id
        self.title         = title
        self.description   = description
        self.reported_by   = reported_by
        self.timestamp     = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        self.assigned_team = assigned_team
        self._severity: Optional[str] = None   # private — set by classify()
        self.ticket_ids: dict         = {}      # populated after API calls
        self._type: Optional[str]     = None    # set by classify()

    # ── Properties ──────────────────────────────────────────────────────────
    @property
    def severity(self) -> Optional[str]:
        return self._severity

    @property
    def incident_type(self) -> Optional[str]:
        return self._type

    # ── Abstract interface ───────────────────────────────────────────────────
    def classify(self) -> None:
        """Must be overridden by every subclass."""
        raise NotImplementedError("Subclasses must implement classify()")

    # ── Static validator ─────────────────────────────────────────────────────
    @staticmethod
    def validate_schema(record: dict) -> bool:
        """
        Validates that a raw JSON record contains all required fields.
        Bonus stretch-goal requirement.
        """
        required = {"id", "title", "description", "reported_by", "timestamp", "assigned_team"}
        missing  = required - record.keys()
        if missing:
            logger.warning("Record %s missing fields: %s", record.get("id", "?"), missing)
            return False
        return True

    # ── Serialisation ────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":            self.id,
            "title":         self.title,
            "description":   self.description,
            "reported_by":   self.reported_by,
            "timestamp":     self.timestamp.isoformat(),
            "assigned_team": self.assigned_team,
            "severity":      self._severity,
            "type":          self._type,
            "ticket_ids":    self.ticket_ids,
        }

    # ── Dunder helpers ───────────────────────────────────────────────────────
    def __str__(self) -> str:
        return (
            f"[{self.id}] {self.title} | "
            f"Type: {self._type} | Severity: {self._severity} | "
            f"Team: {self.assigned_team}"
        )

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.id!r}, severity={self._severity!r})"

    def __lt__(self, other: "Incident") -> bool:
        """Enables sorting: critical < high < medium < low."""
        return (
            _SEVERITY_ORDER.get(self._severity or "low", 3)
            < _SEVERITY_ORDER.get(other._severity or "low", 3)
        )


# ═══════════════════════════════════════════════════════════════════════════════
# NetworkIncident
# ═══════════════════════════════════════════════════════════════════════════════
class NetworkIncident(Incident):
    """Incidents related to network infrastructure."""

    _IP_RE        = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}(?:/\d{1,2})?\b")
    _PROTOCOL_RE  = re.compile(r"\b(TCP|UDP|ICMP|BGP|OSPF|VLAN|MPLS)\b", re.IGNORECASE)
    _NET_KEYWORDS = re.compile(
        r"\b(switch|firewall|router|packet\s+loss|dns|gateway|bandwidth|vlan|port)\b",
        re.IGNORECASE,
    )
    _CRITICAL_RE  = re.compile(r"\b(outage|down|offline|unreachable|production)\b", re.IGNORECASE)
    _HIGH_RE      = re.compile(r"\b(timeout|failing|unavailable)\b", re.IGNORECASE)
    _MEDIUM_RE    = re.compile(r"\b(slow|degraded|warning|intermittent)\b", re.IGNORECASE)

    def __init__(self, affected_host: str = "", protocol: str = "", **kwargs) -> None:
        super().__init__(**kwargs)
        self.affected_host = affected_host
        self.protocol      = protocol

    def classify(self) -> None:
        """Auto-detect affected_host, protocol and severity from title + description."""
        text = f"{self.title} {self.description}"

        # Extract affected host (first IP found) if not already set
        if not self.affected_host:
            ip_match = self._IP_RE.search(text)
            self.affected_host = ip_match.group() if ip_match else "unknown"

        # Extract protocol if not already set
        if not self.protocol:
            proto_match = self._PROTOCOL_RE.search(text)
            self.protocol = proto_match.group().upper() if proto_match else "UNKNOWN"

        # Severity
        if self._CRITICAL_RE.search(text):
            self._severity = "critical"
        elif self._HIGH_RE.search(text):
            self._severity = "high"
        elif self._MEDIUM_RE.search(text):
            self._severity = "medium"
        else:
            self._severity = "low"

        self._type = "network"
        logger.debug("Classified %s → network / %s", self.id, self._severity)

    def escalate(self) -> str:
        """Page the on-call network team."""
        msg = (
            f"🚨 ESCALATION: {self.id} — {self.title}\n"
            f"   Host: {self.affected_host} | Protocol: {self.protocol}\n"
            f"   Severity: {self._severity} | Team: {self.assigned_team}\n"
            f"   Paging on-call network engineer NOW."
        )
        logger.warning(msg)
        print(msg)
        return msg


# ═══════════════════════════════════════════════════════════════════════════════
# AppIncident
# ═══════════════════════════════════════════════════════════════════════════════
class AppIncident(Incident):
    """Incidents related to application errors."""

    _ERROR_CODE_RE = re.compile(
        r"\b([A-Z][A-Z0-9_\-]*-\d{3,}|HTTP[-\s]?\d{3}|NPE[-\s]\d+)\b", re.IGNORECASE
    )
    _EXCEPTION_RE  = re.compile(
        r"\b(\w+Exception|\w+Error)\b"
    )
    _CRITICAL_RE   = re.compile(r"\b(outage|down|production|crash|breach)\b", re.IGNORECASE)
    _HIGH_RE       = re.compile(r"\b(timeout|failing|unavailable|exception|error)\b", re.IGNORECASE)
    _MEDIUM_RE     = re.compile(r"\b(slow|degraded|warning|intermittent)\b", re.IGNORECASE)

    def __init__(self, app_name: str = "", error_code: str = "", **kwargs) -> None:
        super().__init__(**kwargs)
        self.app_name   = app_name
        self.error_code = error_code

    def classify(self) -> None:
        text = f"{self.title} {self.description}"

        # Extract error code
        if not self.error_code:
            ec_match = self._ERROR_CODE_RE.search(text)
            if ec_match:
                self.error_code = ec_match.group()
            else:
                exc_match = self._EXCEPTION_RE.search(text)
                self.error_code = exc_match.group() if exc_match else "UNKNOWN"

        # Derive app name from assigned team or title (simple heuristic)
        if not self.app_name:
            self.app_name = self.assigned_team or "unknown-app"

        # Severity
        if self._CRITICAL_RE.search(text):
            self._severity = "critical"
        elif self._HIGH_RE.search(text):
            self._severity = "high"
        elif self._MEDIUM_RE.search(text):
            self._severity = "medium"
        else:
            self._severity = "low"

        self._type = "app"
        logger.debug("Classified %s → app / %s", self.id, self._severity)

    def get_stack_trace(self) -> str:
        """Return a synthetic log snippet for the incident."""
        snippet = (
            f"--- Stack Trace Snippet for {self.id} ---\n"
            f"Exception: {self.error_code}\n"
            f"  at {self.app_name}.process(Unknown Source)\n"
            f"  at {self.app_name}.run(Main.java:42)\n"
            f"Caused by: {self.description[:120]}...\n"
            f"--- End of Snippet ---"
        )
        logger.info(snippet)
        return snippet


# ═══════════════════════════════════════════════════════════════════════════════
# SecurityIncident
# ═══════════════════════════════════════════════════════════════════════════════
class SecurityIncident(Incident):
    """Incidents related to security threats."""

    _THREAT_RE   = re.compile(
        r"\b(breach|ransomware|brute.?force|malware|phishing|unauthorized|exploit|ddos|sql.?injection|xss)\b",
        re.IGNORECASE,
    )
    _SRC_IP_RE   = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
    _CRITICAL_RE = re.compile(r"\b(breach|ransomware|production|outage|down)\b", re.IGNORECASE)
    _HIGH_RE     = re.compile(r"\b(brute.?force|malware|unauthorized|exploit|ddos)\b", re.IGNORECASE)
    _MEDIUM_RE   = re.compile(r"\b(phishing|warning|intermittent|slow|degraded)\b", re.IGNORECASE)

    def __init__(self, threat_type: str = "", source_ip: str = "", **kwargs) -> None:
        super().__init__(**kwargs)
        self.threat_type = threat_type
        self.source_ip   = source_ip

    def classify(self) -> None:
        text = f"{self.title} {self.description}"

        # Detect threat type
        if not self.threat_type:
            t_match = self._THREAT_RE.search(text)
            self.threat_type = t_match.group().lower() if t_match else "unknown"

        # Detect source IP
        if not self.source_ip:
            ip_match = self._SRC_IP_RE.search(text)
            self.source_ip = ip_match.group() if ip_match else "unknown"

        # Severity
        if self._CRITICAL_RE.search(text):
            self._severity = "critical"
        elif self._HIGH_RE.search(text):
            self._severity = "high"
        elif self._MEDIUM_RE.search(text):
            self._severity = "medium"
        else:
            self._severity = "low"

        self._type = "security"
        logger.debug("Classified %s → security / %s", self.id, self._severity)

    def notify_soc(self) -> str:
        """Send an alert to the Security Operations Centre."""
        alert = (
            f"🔴 SOC ALERT: {self.id}\n"
            f"   Threat Type : {self.threat_type}\n"
            f"   Source IP   : {self.source_ip}\n"
            f"   Severity    : {self._severity}\n"
            f"   Title       : {self.title}\n"
            f"   Team        : {self.assigned_team}\n"
            f"   → Immediate SOC investigation required."
        )
        logger.critical(alert)
        print(alert)
        return alert


# ═══════════════════════════════════════════════════════════════════════════════
# IncidentIterator
# ═══════════════════════════════════════════════════════════════════════════════
class IncidentIterator:
    """
    Iterator that steps through a list of incidents one at a time.
    Supports optional severity filtering.

    Usage:
        for incident in IncidentIterator(incidents, severity_filter='critical'):
            ...
    """

    def __init__(
        self,
        incidents: List[Incident],
        severity_filter: Optional[str] = None,
    ) -> None:
        self._severity_filter = severity_filter
        self._incidents = (
            [i for i in incidents if i.severity == severity_filter]
            if severity_filter
            else list(incidents)
        )
        self._index = 0

    def __iter__(self) -> Iterator[Incident]:
        return self

    def __next__(self) -> Incident:
        if self._index >= len(self._incidents):
            raise StopIteration
        incident = self._incidents[self._index]
        self._index += 1
        return incident

    def __len__(self) -> int:
        return len(self._incidents)


# ═══════════════════════════════════════════════════════════════════════════════
# Batch generator
# ═══════════════════════════════════════════════════════════════════════════════
def batch_incidents(incidents: List[Incident], batch_size: int = 3):
    """
    Generator — yields incidents in batches of batch_size.
    Using a generator expression avoids materialising the full list at once.
    """
    for i in range(0, len(incidents), batch_size):
        yield incidents[i: i + batch_size]