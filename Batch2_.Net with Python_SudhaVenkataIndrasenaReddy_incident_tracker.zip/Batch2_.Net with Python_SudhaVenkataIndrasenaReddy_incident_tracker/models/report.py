# models/report.py
"""
ReportGenerator — produces the final HTML summary report and JSON export.
"""

import json
import logging
import os
from datetime import datetime, timezone
from typing import List

from models.incident import Incident

logger = logging.getLogger(__name__)

# ── Severity badge colours ────────────────────────────────────────────────────
_BADGE_COLOR = {
    "critical": "#dc2626",
    "high":     "#ea580c",
    "medium":   "#ca8a04",
    "low":      "#16a34a",
}

# ── Type icon (emoji) ─────────────────────────────────────────────────────────
_TYPE_ICON = {
    "network":  "🌐",
    "app":      "⚙️",
    "security": "🔒",
    "general":  "📋",
}


class ReportGenerator:
    """Generates an HTML report and a JSON export from a list of incidents."""

    def __init__(self, incidents: List[Incident], generated_at: datetime | None = None) -> None:
        self.incidents    = sorted(incidents)   # sorted via __lt__ (severity)
        self.generated_at = generated_at or datetime.now(timezone.utc)

    # ── HTML report ───────────────────────────────────────────────────────────
    def generate_html(self, output_path: str = "output/report.html") -> str:
        """Write the styled HTML report and return the file path."""
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        # ── summary counts ──────────────────────────────────────────────────
        total    = len(self.incidents)
        critical = sum(1 for i in self.incidents if i.severity == "critical")
        high     = sum(1 for i in self.incidents if i.severity == "high")
        medium   = sum(1 for i in self.incidents if i.severity == "medium")
        low      = sum(1 for i in self.incidents if i.severity == "low")

        by_type = {}
        by_team = {}
        by_sev  = {"critical": critical, "high": high, "medium": medium, "low": low}

        for inc in self.incidents:
            t = inc.incident_type or "general"
            by_type[t] = by_type.get(t, 0) + 1
            by_team[inc.assigned_team] = by_team.get(inc.assigned_team, 0) + 1

        # ── summary pills ───────────────────────────────────────────────────
        def _pill(label, value, color):
            return (
                f'<div class="pill" style="border-top:4px solid {color}">'
                f'<span class="pill-value">{value}</span>'
                f'<span class="pill-label">{label}</span>'
                f'</div>'
            )

        summary_pills = (
            _pill("Total Incidents", total,    "#3b82f6")
            + _pill("Critical",      critical, "#dc2626")
            + _pill("High",          high,     "#ea580c")
            + _pill("Security Alerts",
                    sum(1 for i in self.incidents if i.incident_type == "security"),
                    "#7c3aed")
        )

        # ── type breakdown chips ─────────────────────────────────────────────
        def _chip(label, color):
            return f'<span class="chip" style="background:{color}">{label}</span>'

        type_chips = " ".join(
            _chip(f"{_TYPE_ICON.get(t, '📋')} {t.title()} {cnt}", "#374151")
            for t, cnt in by_type.items()
        )
        sev_chips = " ".join(
            _chip(f"{sev.upper()} {cnt}", _BADGE_COLOR.get(sev, "#374151"))
            for sev, cnt in by_sev.items()
            if cnt > 0
        )
        team_chips = " ".join(
            _chip(f"👥 {team} {cnt}", "#1e40af")
            for team, cnt in by_team.items()
        )

        # ── incident rows ────────────────────────────────────────────────────
        rows_html = ""
        for inc in self.incidents:
            sev_color = _BADGE_COLOR.get(inc.severity, "#6b7280")
            badge = (
                f'<span class="badge" style="background:{sev_color}">'
                f'{(inc.severity or "").upper()}</span>'
            )
            type_icon = _TYPE_ICON.get(inc.incident_type or "general", "📋")
            snow_id   = inc.ticket_ids.get("snow",  "—")
            jira_id   = inc.ticket_ids.get("jira",  "—")
            azure_id  = inc.ticket_ids.get("azure", "—")

            tickets_html = (
                f'<span class="ticket snow" title="ServiceNow">{snow_id}</span>'
                f'<span class="ticket jira" title="Jira">{jira_id}</span>'
                f'<span class="ticket azure" title="Azure">{azure_id}</span>'
            )

            ts = inc.timestamp.strftime("%Y-%m-%d %H:%M") if inc.timestamp else "—"

            rows_html += f"""
            <tr>
              <td class="mono">{inc.id}</td>
              <td>{type_icon} {inc.title}</td>
              <td>{badge}</td>
              <td>{(inc.incident_type or '—').title()}</td>
              <td>{inc.assigned_team}</td>
              <td class="mono small">{ts}</td>
              <td class="tickets">{tickets_html}</td>
            </tr>"""

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>IT Incident Auto-Triage Report</title>
  <style>
    /* ── Reset & Base ───────────────────────────────── */
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      min-height: 100vh;
      padding: 0;
    }}

    /* ── Header ─────────────────────────────────────── */
    .header {{
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      border-bottom: 1px solid #334155;
      padding: 24px 40px;
      display: flex;
      align-items: center;
      gap: 16px;
    }}
    .header-icon {{
      font-size: 32px;
      background: #1d4ed8;
      border-radius: 12px;
      width: 52px; height: 52px;
      display: flex; align-items: center; justify-content: center;
    }}
    .header h1 {{
      font-size: 22px;
      font-weight: 700;
      color: #f1f5f9;
    }}
    .header .subtitle {{
      font-size: 12px;
      color: #94a3b8;
      margin-top: 2px;
    }}

    /* ── Main content ────────────────────────────────── */
    .container {{
      max-width: 1400px;
      margin: 0 auto;
      padding: 32px 40px;
    }}

    /* ── Section titles ──────────────────────────────── */
    .section-title {{
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #64748b;
      margin-bottom: 12px;
    }}

    /* ── Pill cards ──────────────────────────────────── */
    .pills {{
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      margin-bottom: 32px;
    }}
    .pill {{
      background: #1e293b;
      border-radius: 12px;
      padding: 20px 28px;
      min-width: 140px;
      border: 1px solid #334155;
      flex: 1;
    }}
    .pill-value {{
      display: block;
      font-size: 36px;
      font-weight: 700;
      color: #f1f5f9;
      line-height: 1;
    }}
    .pill-label {{
      display: block;
      font-size: 12px;
      color: #94a3b8;
      margin-top: 6px;
    }}

    /* ── Breakdown cards ─────────────────────────────── */
    .breakdown-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 20px;
      margin-bottom: 32px;
    }}
    .breakdown-card {{
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 12px;
      padding: 20px;
    }}
    .breakdown-card h3 {{
      font-size: 13px;
      font-weight: 600;
      color: #94a3b8;
      margin-bottom: 14px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }}
    .chip {{
      display: inline-block;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
      color: #fff;
      margin: 3px 4px 3px 0;
    }}

    /* ── Table ───────────────────────────────────────── */
    .table-wrapper {{
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 12px;
      overflow: hidden;
    }}
    .table-header {{
      padding: 18px 24px;
      border-bottom: 1px solid #334155;
      display: flex;
      align-items: center;
      gap: 10px;
    }}
    .table-header h2 {{
      font-size: 15px;
      font-weight: 600;
      color: #f1f5f9;
    }}
    .table-header .count-badge {{
      background: #3b82f6;
      color: #fff;
      font-size: 11px;
      font-weight: 600;
      padding: 2px 8px;
      border-radius: 10px;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }}
    thead th {{
      background: #0f172a;
      padding: 12px 16px;
      text-align: left;
      font-size: 11px;
      font-weight: 600;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      border-bottom: 1px solid #334155;
    }}
    tbody tr {{
      border-bottom: 1px solid #1e293b;
      transition: background 0.15s;
    }}
    tbody tr:last-child {{ border-bottom: none; }}
    tbody tr:hover {{ background: #0f172a; }}
    td {{
      padding: 12px 16px;
      vertical-align: middle;
      color: #cbd5e1;
    }}
    td:first-child {{ color: #94a3b8; }}

    /* ── Severity badge ──────────────────────────────── */
    .badge {{
      display: inline-block;
      padding: 3px 10px;
      border-radius: 4px;
      font-size: 10px;
      font-weight: 700;
      color: #fff;
      letter-spacing: 0.5px;
    }}

    /* ── Ticket IDs ──────────────────────────────────── */
    .tickets {{ display: flex; flex-direction: column; gap: 3px; }}
    .ticket {{
      font-size: 10px;
      font-family: 'Courier New', monospace;
      padding: 2px 6px;
      border-radius: 3px;
      white-space: nowrap;
    }}
    .ticket.snow  {{ background: #14532d; color: #86efac; }}
    .ticket.jira  {{ background: #1e3a5f; color: #93c5fd; }}
    .ticket.azure {{ background: #312e81; color: #c4b5fd; }}

    /* ── Utilities ───────────────────────────────────── */
    .mono  {{ font-family: 'Courier New', monospace; }}
    .small {{ font-size: 11px; }}

    /* ── Footer ──────────────────────────────────────── */
    .footer {{
      text-align: center;
      padding: 24px;
      font-size: 11px;
      color: #475569;
      border-top: 1px solid #334155;
      margin-top: 40px;
    }}
  </style>
</head>
<body>

  <div class="header">
    <div class="header-icon">🛡️</div>
    <div>
      <h1>IT Incident Auto-Triage Report</h1>
      <div class="subtitle">
        Generated: {self.generated_at.strftime('%Y-%m-%d %H:%M:%S UTC')}
        &nbsp;|&nbsp; Total Incidents: {total}
      </div>
    </div>
  </div>

  <div class="container">

    <!-- ── Summary pills ── -->
    <div class="section-title">Summary</div>
    <div class="pills">
      {summary_pills}
    </div>

    <!-- ── Breakdown cards ── -->
    <div class="breakdown-grid">
      <div class="breakdown-card">
        <h3>Breakdown by Type</h3>
        {type_chips}
      </div>
      <div class="breakdown-card">
        <h3>Breakdown by Severity</h3>
        {sev_chips}
      </div>
      <div class="breakdown-card">
        <h3>Breakdown by Team</h3>
        {team_chips}
      </div>
    </div>

    <!-- ── Incident table ── -->
    <div class="table-wrapper">
      <div class="table-header">
        <h2>Incident Detail</h2>
        <span class="count-badge">{total}</span>
      </div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Severity</th>
            <th>Type</th>
            <th>Team</th>
            <th>Timestamp</th>
            <th>Tickets (SNOW / Jira / Azure)</th>
          </tr>
        </thead>
        <tbody>
          {rows_html}
        </tbody>
      </table>
    </div>

  </div>

  <div class="footer">
    Produced by Incident Auto-Triage &amp; Tracker — Mini Project 3
  </div>

</body>
</html>"""

        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write(html)

        logger.info("HTML report written to %s", output_path)
        print(f"\n✅ HTML report written → {output_path}")
        return output_path

    # ── JSON export ───────────────────────────────────────────────────────────
    def export_json(self, output_path: str = "output/report.json") -> str:
        """Write a JSON summary of all incidents and return the file path."""
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        data = {
            "generated_at": self.generated_at.isoformat(),
            "total":        len(self.incidents),
            "incidents":    [i.to_dict() for i in self.incidents],
        }
        with open(output_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, default=str)
        logger.info("JSON export written to %s", output_path)
        print(f"✅ JSON export written → {output_path}")
        return output_path